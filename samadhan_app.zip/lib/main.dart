import 'package:flutter/material.dart';

void main() {
  runApp(SamadhanApp());
}

class SamadhanApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Samadhan',
      theme: ThemeData(primarySwatch: Colors.green),
      home: Scaffold(
        appBar: AppBar(title: Text('Samadhan')),
        body: Center(
          child: Text(
            'Welcome to Samadhan\nMade in India 🇮🇳',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20),
          ),
        ),
      ),
    );
  }
}
